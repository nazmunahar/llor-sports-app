# LLOR Sports — শুরু করার নির্দেশিকা (বাংলা)

এই প্রজেক্টে LLOR Sports-এর প্রাথমিক মোবাইল-ফ্রেন্ডলি অ্যাপ এবং GitHub Actions-এ Android APK বানানোর ব্যবস্থা আছে।

## কী আছে
- বাংলা ও English ভাষা পরিবর্তন
- Cricket, Football, Videos, Saved, Settings স্ক্রিন
- নমুনা খবর ও নমুনা ম্যাচ কার্ড
- সেভ করা খবর ও সেটিংস ডিভাইসের localStorage-এ রাখা
- নিজের YouTube ও স্কোর ওয়েবসাইটের লিংক Settings থেকে যোগ করা
- Android APK বিল্ড workflow

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- খবর/স্কোরের নমুনা লাইভ তথ্য নয়। প্রকাশের আগে যাচাইকৃত কনটেন্ট যোগ করুন।
- লাইভ স্কোর বা স্বয়ংক্রিয় সংবাদ ফিড যুক্ত করা নেই।
- অ্যাপের মূল UI অফলাইনে কাজ করে, কিন্তু বাইরের লিংক খুলতে ইন্টারনেট দরকার।
- APK হলো debug APK; এটি পরীক্ষা ও ব্যক্তিগত ইনস্টলেশনের জন্য। Play Store প্রকাশের আগে release signing, নীতি, আইকন ও আরও পরীক্ষা লাগবে।
- Capacitor/Android SDK-এর ভবিষ্যৎ আপডেটে workflow সামঞ্জস্য করতে হতে পারে।

## GitHub-এ কীভাবে বসাবেন (মোবাইল থেকে)
1. GitHub-এ `llor-sports-app` নামে একটি নতুন repository তৈরি করুন।
2. এই ZIP-টি extract করুন।
3. `index.html` ফাইলটি repository-র `public` ফোল্ডারের ভিতরে আপলোড করুন।
4. `manifest.json`-ও `public` ফোল্ডারে রাখুন।
5. `package.json`, `capacitor.config.json` এবং `.github/workflows/build-apk.yml` repository-তে একই পথ ও নামে আপলোড করুন।
6. নিশ্চিত করুন branch-এর নাম `main`। GitHub repository-র Actions ট্যাবে যান।
7. `Build LLOR Sports APK` workflow-টি চলতে দিন। Push করলে এটি নিজে থেকেই চলবে; চাইলে Actions থেকে `Run workflow`-ও ব্যবহার করতে পারবেন।
8. workflow সফল হলে run খুলে নিচে `Artifacts` থেকে `LLOR-Sports-debug-APK` ডাউনলোড করুন।
9. ZIP artifact extract করে `app-debug.apk` ফোনে ইনস্টল করুন। Android চাইলে ব্রাউজার/ফাইল ম্যানেজার থেকে APK ইনস্টল করার অনুমতি দিতে হবে।

## ফাইলের গঠন
- `public/index.html` — অ্যাপের স্ক্রিন ও আচরণ
- `public/manifest.json` — অ্যাপ মেটাডেটা
- `package.json` — Node/Capacitor dependencies
- `capacitor.config.json` — Android অ্যাপ পরিচয় ও web asset path
- `.github/workflows/build-apk.yml` — APK বিল্ডের স্বয়ংক্রিয় ধাপ

## নিজের চ্যানেল/স্কোর লিংক
অ্যাপ ইনস্টল করার পর Settings-এ গিয়ে YouTube channel URL এবং score website URL বসিয়ে Save করুন। স্কোর লিংক না দিলে বোতামটি সাধারণ ওয়েব সার্চ খুলবে।
